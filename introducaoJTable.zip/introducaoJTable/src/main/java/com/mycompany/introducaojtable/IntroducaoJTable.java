/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.introducaojtable;

import javax.swing.JFrame;

/**
 *
 * @author 202312030003
 */
public class IntroducaoJTable {

    public static void main(String[] args) {
        JanelaPrincipal janelaPrincipal = new JanelaPrincipal();
        janelaPrincipal.setVisible(true);
        janelaPrincipal.setSize(800,600);
        janelaPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
